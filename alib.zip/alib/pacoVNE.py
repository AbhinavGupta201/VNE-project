class PowerAwareVNEAlgorithm(Algorithm):
    def __init__(self, vne_module):
        super().__init__(vne_module)
    
    def run(self):
        embeddings = {}
        for req in self.requests:
            # Select a physical node for each virtual node
            node_map = {}
            for v_node in req.nodes:
                node_map[v_node] = self.select_node(req, v_node)

            # Compute the energy consumption of the embedding
            energy = self.compute_energy(node_map)

            # Embed the virtual links
            link_map = {}
            for v_link in req.links:
                src_node = node_map[v_link.src]
                dst_node = node_map[v_link.dst]
                link_map[v_link] = self.embed_link(src_node, dst_node, v_link.capacity)

            # Report the successful embedding of the request
            embeddings[req] = {'nodes': node_map, 'links': link_map}
            self.request_success(req, energy=energy)

        return embeddings

from alib import Driver

driver = Driver()
driver.run(vne_instance=vne, algorithm=PowerAwareVNEAlgorithm(vne))

