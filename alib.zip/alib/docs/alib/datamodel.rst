``alib.datamodel``
==================

.. automodule:: alib.datamodel
  :members:
  :undoc-members: