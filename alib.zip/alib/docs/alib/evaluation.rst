``alib.evaluation``
===================

.. automodule:: alib.evaluation
  :members:
  :undoc-members: